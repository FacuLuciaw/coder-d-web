/*Mi idea de proyecto final es una pagina de venta de productos, que ofrezca la posibilidad de pagarlos en cuotas*/

//Objetos

const productos = [

    {
        codigo: "AA000",
        descripcion: "Buzo Nirvana",
        talle: "small",
        precio: 1500,
    },

    {
        codigo: "AA001",
        descripcion: "Buzo Ramones",
        talle: "medium",
        precio: 1600,
    },

    {
        codigo: "AA002",
        descripcion: "Buzo Rolling Stones",
        talle: "large",
        precio: 1700,
    }

]

//Busqueda de producto

const productoBuscado = productos.find((productos) => productos.descripcion == "Buzo Nirvana");

console.log(productoBuscado)

const filtrarProducto = productos.filter((productos) => productos.descripcion.includes("Ramones"));

console.log(filtrarProducto)

console.log(productos.some((productos) => productos.codigo == "AA004"))

/*Suma los valores de los productos*/

function sumaDeProductos (array){
    let suma = 0;

    for (let i = 0; i < array.length; i++) {
        suma += array[i].precio;
    }

return suma; 
} 

let resultado = sumaDeProductos(productos);
console.log(resultado);

/*Divide el valor de los productos en 12 cuotas*/
function pagoEnCuotas (cuotas){
    return resultado/cuotas;
}
let valorCuotas = pagoEnCuotas(12);
console.log(valorCuotas);

/*Calcula el valor de el interes*/
function interesPorCuotas (interes){
    return valorCuotas*(interes/100);   
}
let valorInteres = interesPorCuotas(2);
console.log(valorInteres);

/*Suma el valor de las cuotas mas el valor del interes, calculando asi el valor final de cada cuota*/
let valorFinal = valorCuotas + valorInteres;
console.log(valorFinal);